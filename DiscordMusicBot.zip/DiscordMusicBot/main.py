# Gerekli kütüphaneler
import discord
from discord.ext import commands
import yt_dlp
import asyncio
import functools

# 1. TEMEL BOT AYARLARI
# -----------------------------------------------------------------------------
# Bot'un hem '!' gibi prefix komutlarını hem de '/' slash komutlarını algılaması için
# gerekli olan "intents" (niyetler) ayarlanıyor.
intents = discord.Intents.default()
intents.message_content = True  # Mesaj içeriğini okuma izni (!komutlar için)
intents.guilds = True
intents.voice_states = True

# Bot objesi oluşturuluyor. Prefix '!' olarak belirlendi.
bot = commands.Bot(command_prefix='!', intents=intents)

# 2. MÜZİK İÇİN GEREKLİ AYARLAR VE DEĞİŞKENLER
# -----------------------------------------------------------------------------
# yt-dlp için ayarlar. Sadece en iyi ses formatını arayacak, video indirmeyecek.
YDL_OPTIONS = {
    'format': 'bestaudio/best',
    'noplaylist': 'True',
    'quiet': True,  # Terminali temiz tutar
}
FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn',
}

# Sunucu bazlı kuyrukları tutmak için bir sözlük (dictionary)
queues = {}

# 3. BOT HAZIR OLDUĞUNDA ÇALIŞACAK EVENT
# -----------------------------------------------------------------------------
@bot.event
async def on_ready():
    print(f'{bot.user.name} olarak giriş yapıldı ve komutlar senkronize ediliyor...')
    try:
        # Slash komutlarını Discord ile senkronize et
        synced = await bot.tree.sync()
        print(f"{len(synced)} adet slash komutu senkronize edildi.")
    except Exception as e:
        print(f"Senkronizasyon hatası: {e}")

# 4. YARDIMCI FONKSİYON: SIRADAKİ ŞARKIYI ÇALMA
# -----------------------------------------------------------------------------
async def check_queue(ctx, guild_id):
    if guild_id in queues and queues[guild_id]:
        voice_client = ctx.guild.voice_client
        if not voice_client.is_playing() and not voice_client.is_paused():
            # Sıradaki şarkıyı al
            url = queues[guild_id].pop(0)
            
            with yt_dlp.YoutubeDL(YDL_OPTIONS) as ydl:
                info = ydl.extract_info(url, download=False)
                audio_url = info['url']
            
            source = discord.FFmpegPCMAudio(audio_url, **FFMPEG_OPTIONS)
            voice_client.play(source, after=lambda e: bot.loop.create_task(check_queue(ctx, guild_id)))
            
            await ctx.send(f"🎶 Sıradaki şarkı: **{info['title']}**")

# 5. KOMUTLAR (HEM PREFIX HEM SLASH)
# -----------------------------------------------------------------------------

# SES KANALINA GİRME KOMUTU
@bot.command(name='join', help='Bot ses kanalına katılır.')
async def join_prefix(ctx):
    if not ctx.author.voice:
        await ctx.send("Bir ses kanalında değilsin!")
        return
    channel = ctx.author.voice.channel
    await channel.connect()
    await ctx.send(f"**{channel}** kanalına katıldım!")

@bot.tree.command(name='join', description='Bot ses kanalına katılır.')
async def join_slash(interaction: discord.Interaction):
    if not interaction.user.voice:
        await interaction.response.send_message("Bir ses kanalında değilsin!", ephemeral=True)
        return
    channel = interaction.user.voice.channel
    await channel.connect()
    await interaction.response.send_message(f"**{channel}** kanalına katıldım!")

# MÜZİK ÇALMA KOMUTU (ANA MANTIK)
# DONMA SORUNUNU ÇÖZMEK İÇİN GÜNCELLENDİ
async def play_logic(ctx, search: str):
    voice_client = ctx.guild.voice_client
    
    if not voice_client:
        if not ctx.author.voice:
            if ctx.interaction:
                await ctx.interaction.response.send_message("Önce bir ses kanalına katılmalısın!", ephemeral=True)
            else:
                await ctx.send("Önce bir ses kanalına katılmalısın!")
            return
        await ctx.author.voice.channel.connect()
        voice_client = ctx.guild.voice_client

    loop = bot.loop
    search_func = functools.partial(
        yt_dlp.YoutubeDL(YDL_OPTIONS).extract_info, 
        f"ytsearch:{search}" if not search.startswith('https://') else search, 
        download=False
    )
    
    if ctx.interaction:
        await ctx.interaction.response.send_message(f"🔎 **{search}** aranıyor...")
        message_destination = await ctx.interaction.original_response()
    else:
        message_destination = ctx
    
    try:
        data = await loop.run_in_executor(None, search_func)
    except Exception as e:
        await message_destination.send("Şarkı bulunamadı veya bir hata oluştu.")
        print(e)
        return

    if 'entries' in data:
        info = data['entries'][0]
    else:
        info = data

    audio_url = info['url']
    song_title = info['title']
    original_url = info.get('original_url') or info.get('webpage_url')
    guild_id = ctx.guild.id

    if voice_client.is_playing() or voice_client.is_paused():
        if guild_id not in queues:
            queues[guild_id] = []
        queues[guild_id].append(original_url)
        
        if ctx.interaction:
            await message_destination.edit(content=f"✅ Sıraya eklendi: **{song_title}**")
        else:
            await message_destination.send(f"✅ Sıraya eklendi: **{song_title}**")
    else:
        source = discord.FFmpegPCMAudio(audio_url, **FFMPEG_OPTIONS)
        voice_client.play(source, after=lambda e: bot.loop.create_task(check_queue(ctx, guild_id)))
        
        if ctx.interaction:
            await message_destination.edit(content=f"🎶 Şimdi çalıyor: **{song_title}**")
        else:
            await message_destination.send(f"🎶 Şimdi çalıyor: **{song_title}**")


# Play komutları ana mantığı çağırır
@bot.command(name='play', help='Belirtilen şarkıyı çalar veya sıraya ekler.')
async def play_prefix(ctx, *, search: str):
    await play_logic(ctx, search)

@bot.tree.command(name='play', description='Belirtilen şarkıyı çalar veya sıraya ekler.')
async def play_slash(interaction: discord.Interaction, search: str):
    ctx = await bot.get_context(interaction)
    await play_logic(ctx, search)


# DURDURMA KOMUTU
@bot.command(name='stop', help='Müziği durdurur ve sırayı temizler.')
async def stop_prefix(ctx):
    voice_client = ctx.guild.voice_client
    if voice_client and voice_client.is_playing():
        queues[ctx.guild.id] = []
        voice_client.stop()
        await ctx.send("Müzik durduruldu ve sıra temizlendi.")

@bot.tree.command(name='stop', description='Müziği durdurur ve sırayı temizler.')
async def stop_slash(interaction: discord.Interaction):
    voice_client = interaction.guild.voice_client
    if voice_client and voice_client.is_playing():
        queues[interaction.guild.id] = []
        voice_client.stop()
        await interaction.response.send_message("Müzik durduruldu ve sıra temizlendi.")
    else:
        await interaction.response.send_message("Şu anda çalan bir müzik yok.", ephemeral=True)
        
# ÇIKIŞ KOMUTU
@bot.command(name='leave', help='Bot ses kanalından ayrılır.')
async def leave_prefix(ctx):
    voice_client = ctx.guild.voice_client
    if voice_client and voice_client.is_connected():
        await voice_client.disconnect()
        await ctx.send("Ses kanalından ayrıldım.")

@bot.tree.command(name='leave', description='Bot ses kanalından ayrılır.')
async def leave_slash(interaction: discord.Interaction):
    voice_client = interaction.guild.voice_client
    if voice_client and voice_client.is_connected():
        await voice_client.disconnect()
        await interaction.response.send_message("Ses kanalından ayrıldım.")
    else:
        await interaction.response.send_message("Zaten bir ses kanalında değilim.", ephemeral=True)


# 6. BOTU ÇALIŞTIRMA
# -----------------------------------------------------------------------------
# 'YOUR_BOT_TOKEN' kısmını Discord Developer Portal'dan aldığınız kendi bot token'ınız ile değiştirin.
bot.run('YOUR_BOT_TOKEN')
